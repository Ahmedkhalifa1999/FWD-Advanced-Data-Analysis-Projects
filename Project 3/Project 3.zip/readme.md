# Prosper Loan Dataset
## by Ahmed Khalifa


## Dataset

> Proper Loan Datset
> It is a huge dataset that contains a wide range of data about loans made by prosper company, ranging from data about the loans themselves to data about loanees.


## Summary of Findings

> A significant portion of loans are defaulted which is a loss to the company.
> A large portion of loans is for debt consolidation
> Surprisingly, income range, home ownership and emplyment status don't affect whether a loanee will complete the loan or not.
> Loan Interest, Credit Score and and Loan Term are factors which significantly contribute to loan outcome (Defaulted or Completed). 


## Key Insights for Presentation

> Loans with higher interest have ahigher probability of being defaulted.
> Loanees with higher credit scores are more likely to complete their loan.
> Shorter term loans are more likely to be completed